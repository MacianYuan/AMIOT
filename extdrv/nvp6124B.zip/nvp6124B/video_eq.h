#ifndef _VIDEO_EQ_H_
#define _VIDEO_EQ_H_

void nvp6124_set_equalizer(unsigned char ch);
void nvp6124b_set_equalizer(unsigned char ch);

#endif

