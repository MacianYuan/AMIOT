#ifndef _AUDIO_H_
#define _AUDIO_H_

extern void audio_init(unsigned char recmaster, unsigned char pbmaster, unsigned char ch_num, unsigned char samplerate, unsigned char bits);

#endif
